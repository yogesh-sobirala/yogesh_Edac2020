class Patterns7
{
    public static void main(String args[])
    {
            int i,j,k;
            for(i=1; i<=9; i++)
            {
                for(k=1; k<i+1; k++)
                {
                    System.out.print(" ");
		 
                }
                for(j=i; j<=9; j++)
{
                    System.out.print(i+" ");
            }
                  System.out.println(  );
}
}
    }